package com.example.lekcja;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Pobieranie referencji do widoków
        LinearLayout layout = findViewById(R.id.main_layout);
        TextView tekst = findViewById(R.id.textView);
        EditText editText = findViewById(R.id.editText);
        Button przycisk = findViewById(R.id.przycisk);
        Button drugiPrzycisk = findViewById(R.id.drugi_przycisk);
        Button przyciskZmiana = findViewById(R.id.przycisk_zmiana);
        Button przyciskTlo = findViewById(R.id.przycisk_tlo);
        Button przyciskWpisanyTekst = findViewById(R.id.przycisk_wpisany_tekst);
        Button przyciskZamknij = findViewById(R.id.przycisk_zamknij);


        przycisk.setOnClickListener(v -> Toast.makeText(MainActivity.this, "Kliknięto przycisk!", Toast.LENGTH_SHORT).show());

        drugiPrzycisk.setOnClickListener(v -> Toast.makeText(MainActivity.this, "Drugi przycisk działa!", Toast.LENGTH_SHORT).show());

        przyciskZmiana.setOnClickListener(v -> tekst.setText("Witaj w Android Studio!"));

        przyciskTlo.setOnClickListener(v -> layout.setBackgroundColor(Color.RED));

        przyciskWpisanyTekst.setOnClickListener(v -> {
            String wpisanyTekst = editText.getText().toString();
            Toast.makeText(MainActivity.this, wpisanyTekst, Toast.LENGTH_SHORT).show();
        });

        przyciskZamknij.setOnClickListener(v -> finish());
    }
}